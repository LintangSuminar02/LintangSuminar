Array = []
total = 0
x = int(input("Masukkan jumlah kata : "))
for i in range(x):
    Array.append(input(f"Masukkan kata : ")) 
    array = ["apel", "jeruk", "mangga", "pisang", "anggur"]
    x = []
# Input kata yang akan dicari
kata_cari = input("Masukkan kata yang ingin dicari: ")
if (array, kata_cari):
    print("kata", kata_cari, "ditemukan pada urutan ke-", (0+i))
else:
    print("Kata", kata_cari, "tidak ditemukan")