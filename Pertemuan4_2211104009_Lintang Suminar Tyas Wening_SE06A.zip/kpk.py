print("====PROGRAM SEDERHANA MENCARI KPK====")
bilangan1 = int(input("Masukkan bilangan pertama = "))
bilangan2 = int(input("Masukkan bilangan kedua = "))

# Mencari KPK dengan perulangan while
i = 1
while True:
    if (i % bilangan1 == 0) and (i % bilangan2 == 0):
        kpk = i
        break
    i += 1

# Menampilkan hasil KPK
print("KPK dari", bilangan1, "dan", bilangan2, "adalah", kpk)