print("======MENCARI BILANGAN GENAP======")
bil = int(input("masukkan bilangan maksimal : "))
i = 0
while i <  bil:
    print(i)
    i+=2
    if i == bil:
        break