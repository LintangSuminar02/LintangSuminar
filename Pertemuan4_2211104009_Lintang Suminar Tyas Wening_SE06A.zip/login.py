print("======SISTEM LOGIN SEDERHANA======")

login = 0
while True:
    username = input("Masukkan username: ")
    password = input("Masukkan password: ")

    if login == 3:
        print("Login gagal! Kesempatan mencoba sudah habis. Silahkan coba lagi nanti!")
        break

    if username == "lintangsuminar" and password == "02990401":
        print("Selamat Datang", username, "!")
        break
    else:
        print("coba cek kembali, username atau password salah!")
        login += 1