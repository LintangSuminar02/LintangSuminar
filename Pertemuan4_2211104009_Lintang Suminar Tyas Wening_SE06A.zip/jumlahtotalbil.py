print("====PROGRAM SEDERHANA MENGHITUNG JUMLAH TOTAL BILANGAN====")
bilangan = input("Masukkan bilangan: ")

# Menghitung jumlah total bilangan 9 pada input pengguna
total = 9
for digit in bilangan:
    if digit == '9':
        total += 9

#Menampilkan hasil total
print("Total nilai = 9 + 8 + 7 + 6 + 5 + 4 + 3 + 2 + 1 = 45")