print("====PROGRAM SEDERHANA MENGHITUNG PANGKAT====")
bilangan = int(input("Masukkan bilangan = "))
pangkat = int(input("Masukkan pencacah = "))

# Menghitung hasil pangkat dengan perulangan while
hasil = 1
i = 1
while i <= pangkat:
    hasil *= bilangan
    i += 1

# Menampilkan hasil pangkat
print("Hasil pangkat = ", hasil)