#i = 0
#while i <= 7:
    #print("Hallo world!")
    #i += 1

a = 1
b = 10
while a < b:
    print("Step ke-", a)
    a += 1