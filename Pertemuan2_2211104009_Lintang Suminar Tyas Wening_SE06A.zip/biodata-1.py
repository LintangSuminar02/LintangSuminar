nama_lengkap = "Lintang Suminar Tyas Wening"
ttl = "Makassar, 22 Februari 2004"
alamat = "Jl. Sidodadi, RT.3/RW.2, Purwokerto Kidul"
no_hp = "08971619206"
program_study = "Software Engineering"
hobi = "Mendengarkan musik"

#input integer
print("Biodata")
print("Nama Lengkap: Lintang Suminar Tyas Wening")
print("TTL: Makassar, 22 Februari 2004 ")
print("Alamat: Jl. Sidodadi, RT.3/RW.2, Purwokerto Kidul ")
print("No. hp: 08971619206 ")
print("Program Study: Software Engineering ")
print("Hobi: Mendengarkan musik ")