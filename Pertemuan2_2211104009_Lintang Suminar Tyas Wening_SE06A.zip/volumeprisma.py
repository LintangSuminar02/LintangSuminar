#Menghitung volume prisma segitiga
alas = 8
tinggi = 4
tinggi_prisma = 9
volume_prisma = 0.5 * alas * tinggi * tinggi_prisma
print("Volume prisma segitiga dengan alas", alas, ", tinggi", tinggi, ", dan tinggi prisma", tinggi_prisma, "adalah", volume_prisma)