#menghitung volume kubus
sisi = 9
volume = sisi * sisi * sisi
print("Volume kubus dengan sisi", sisi, "adalah", volume)