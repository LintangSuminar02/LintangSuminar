#input string
nama = input("Nama: ")
nim = input("Nim: ")
print("Nama:"+nama)
print("Nim:"+ nim)

#input integer
panjang = int(input("PANJANG: "))
lebar = int(input("LEBAR: "))
luas = panjang * lebar
print("Luas Persegi Panjang:", luas)