print("Hallo, selamat pagi!") #cetak string secara langsung

belajar = "Belajar Python"
print(belajar) #cetak string menggunakan variabel

nama = "Lintang"
print("Selamat pagi{}".format (nama))#cetak string fungsi format)

Lintang = "Nasi goreng"
Maria = "Bakso"
Putri = "Seblak"
print(f"Makanan favorit = {Lintang}")
print(f"Makanan favorit = {Maria}")
print(f"Makanan favorit = {Putri}")

#print(Makanan favorit Lintang = {}".format (Lintang))
#print(Makanan favorit Maria = {}".format (Maria))
#print(Makanan favorit Putri = {}".format (Putri))
#print(Makanan favorit Putri \n = {}".format (Putri)