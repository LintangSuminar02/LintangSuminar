def linear_search(keyword, data):
    for i in range(len(data)):
        if str(data[i]).lower() == keyword.lower():
            print(f"Keyword {keyword} has found at indeks {i}")
            return
    print(f"Keyword {keyword} not found")
    return -1

data = [32, 7, 44, 21, 61, 25, 45]
keyword = input("Input keyword : ")
linear_search(keyword, data)