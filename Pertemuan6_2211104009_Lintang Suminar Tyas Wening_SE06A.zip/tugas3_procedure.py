import sys

def tambah(a, b):
    hasil = a + b
    print("Hasil penjumlahan:", hasil)

def kurang(a, b):
    hasil = a - b
    print("Hasil pengurangan:", hasil)

def kali(a, b):
    hasil = a * b
    print("Hasil perkalian:", hasil)

def bagi(a, b):
    if b != 0:
        hasil = a / b
        print("Hasil pembagian:", hasil)
    else:
        print("Error: Pembagian dengan nol tidak valid")

def exit_program():
    print("Terima kasih telah menggunakan kalkulator sederhana.")
    sys.exit()

def main_menu():
    print("=== Kalkulator ===")
    print("Pilih operasi:")
    print("1. Penjumlahan")
    print("2. Pengurangan")
    print("3. Perkalian")
    print("4. Pembagian")
    print("5. Keluar")
    print("6. Menu")

def main():
    while True:
        main_menu()

        pilihan = int(input("Masukkan pilihan : "))
        
        if pilihan == 5:
            exit_program()
        if pilihan == 6:
            main_menu()
        angka1 = int(input("Masukkan angka pertama: "))
        angka2 = int(input("Masukkan angka kedua: "))

        if pilihan == 1:
            tambah(angka1, angka2)
        elif pilihan == 2:
            kurang(angka1, angka2)
        elif pilihan == 3:
            kali(angka1, angka2)
        elif pilihan == 4:
            bagi(angka1, angka2)
        else:
            print("Pilihan tidak valid")
        print()
main()
