def keliling_persegi(sisi):
    keliling = 4 * sisi
    return keliling

def luas_persegi(sisi):
    luas = sisi * sisi
    return luas

def sisi():
    sisi = int(input("Masukkan panjang sisi persegi: "))
    print("Keliling persegi:", keliling_persegi(sisi))
    print("Luas persegi:", luas_persegi(sisi))
sisi()