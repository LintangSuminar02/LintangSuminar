import math

def keliling_lingkaran(jari_jari):
    keliling = 2 * math.pi * jari_jari
    return round(keliling, 2)

def luas_lingkaran(jari_jari):
    luas = math.pi * jari_jari**2
    return round(luas, 2)

r = int(input("Masukkan jari-jari lingkaran: "))
keliling = keliling_lingkaran(r)
luas = luas_lingkaran(r)

print("Keliling lingkaran :", r, "adalah", keliling)
print("Luas lingkaran :", r, "adalah", luas)