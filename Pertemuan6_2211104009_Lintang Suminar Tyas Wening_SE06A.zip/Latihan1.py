def hitung_keliling_dan_luas_persegi():
    sisi = int(input("Masukkan panjang sisi persegi: "))
    keliling = 4 * sisi
    luas = sisi * sisi
    print("Keliling persegi:", keliling)
    print("Luas persegi:", luas)
 

hitung_keliling_dan_luas_persegi()