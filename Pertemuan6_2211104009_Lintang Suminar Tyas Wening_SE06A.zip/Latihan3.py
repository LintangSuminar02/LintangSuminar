def bandingkan_bilangan(nilai1, nilai2):
    if nilai1 > nilai2:
        print("Bilangan yang lebih besar adalah", bilangan1)
    elif nilai2 > nilai1:
        print("Bilangan yang lebih besar adalah", bilangan2)
    else:
        print("Tidak ada yang lebih besar")

bilangan1 = int(input("Masukkan bilangan 1: "))
bilangan2 = int(input("Masukkan bilangan 2: "))

bandingkan_bilangan(bilangan1, bilangan2)