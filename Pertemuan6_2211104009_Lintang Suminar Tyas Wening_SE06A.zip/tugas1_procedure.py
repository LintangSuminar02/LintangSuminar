def ganjil_genap(bilangan):
    if bilangan % 2 == 0:
        print("Bilangan yang anda masukkan adalah bilangan genap")
    else:
        print("Bilangan yang anda masukkan adalah bilangan ganjil")

def bilangan():
    bilangan = int(input("Masukkan bilangan: "))
    ganjil_genap(bilangan)

bilangan()