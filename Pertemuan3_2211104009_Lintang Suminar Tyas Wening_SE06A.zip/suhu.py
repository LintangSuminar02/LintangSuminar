suhu = float(input("Masukkan suhu air dalam derajat Celsius: "))

if suhu <= 0:
    print("Air berwujud padat (es)")
elif suhu < 100:
    print("Air berwujud cair")
else:
    print("Air berwujud gas")