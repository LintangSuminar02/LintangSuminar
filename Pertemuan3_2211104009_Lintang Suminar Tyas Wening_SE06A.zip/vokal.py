#huruf vokal konsonan
user = input("Masukkan sebuah huruf: ")
if user.isalpha():
    if user.lower() in ['a', 'i', 'u', 'e', 'o']:
        print("adalah huruf vokal")
    else:
        print("bukan huruf vokal")
else:
    print("Inputan bukan huruf")